
namespace WebApp
{
	using System;
	using System.Text;
	
    public class Constants
    {	  
		public static string ConnectionString = "Contact Points = localhost; Port = 9042";

        public static int MaximumNumberOfRows = 24;

        public static string CamelCase(string name)
        {
            var cSharpified = CSharpifyName(name);
            return cSharpified.Substring(0, 1).ToLowerInvariant() + cSharpified.Substring(1);
        }

        public static string CSharpifyName(string name)
        {
            var cassandrified = new StringBuilder();
            var previousWasUnderline = false;
            foreach (var c in name)
            {
                if (c == '_')
                {
                    previousWasUnderline = true;
                    continue;
                }
                cassandrified.Append(
                    cassandrified.Length == 0 || previousWasUnderline ?
                        char.ToUpperInvariant(c) :
                        c);
                previousWasUnderline = false;
            }
            return cassandrified.ToString();
        }
    }
}
