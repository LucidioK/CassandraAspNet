namespace WebApp
{
    using System;
    using System.Collections.Generic;
    using WebApp.Model;

    public class UdtMapping
    {
        public static bool AlreadyMapped = false;

        public static void Map(Cassandra.Session session)
        {
            if (!AlreadyMapped)
            {
                Category.Map(session);
                Tag.Map(session);
            }
            AlreadyMapped = true;
        }
        public UdtMapping() { }

    }
}