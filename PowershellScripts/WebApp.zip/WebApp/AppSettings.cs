
namespace WebApp
{
    public class AppSettings
    {
 
    }
}
